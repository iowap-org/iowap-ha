"""CLI task subcommands — submit / result / list / note / wait (T-117; list: T-248).

Handler signatures are plain ``(client, args) -> int``; the
``node_cli.with_client`` decorator is applied at parser-registration time
in the facade, so this module never imports ``node_cli`` (avoids a
circular import and keeps the ``cli.RelayClient`` monkeypatch working).
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from typing import Any

import httpx

from nodes.common.forward import (
    FORWARD_CAPABILITY,
    ForwardSlotError,
    apply_forward_slot,
    forward_hint,
)
from nodes.common.relay_client import RelayClient


def _parse_stage_arg(stage: str) -> tuple[str, dict[str, Any]]:
    """Parse ``<cap>:<json_payload>`` into (capability, payload)."""
    if ":" not in stage:
        raise SystemExit(f"invalid --stage value {stage!r}; expected <capability>:<json-payload>")
    cap, _, payload_str = stage.partition(":")
    cap = cap.strip()
    if not cap:
        raise SystemExit(f"invalid --stage value {stage!r}; empty capability")
    try:
        payload = json.loads(payload_str) if payload_str.strip() else {}
    except json.JSONDecodeError as exc:
        raise SystemExit(f"invalid --stage payload JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise SystemExit("--stage payload must be a JSON object")
    return cap, payload


_RELAY_ERROR_CODE_PATTERN = re.compile(r"^([a-z_]+): (.*)$", re.DOTALL)


def _parse_relay_error(response: httpx.Response) -> tuple[str | None, str]:
    """Extract ("<code>", "<message>") from a relay error response.

    Reads the FastAPI error shape ``{"detail": "<code>: <message>"}``;
    falls back to the raw response text. Returns ``(None, detail_or_empty)``
    when the detail does not match the ``<lowercase-snake-code>: <message>``
    shape. Pure — never raises.
    """
    try:
        body = response.json()
    except (ValueError, TypeError):
        body = None
    detail = body.get("detail") if isinstance(body, dict) else None
    if not isinstance(detail, str):
        detail = response.text or ""
    match = _RELAY_ERROR_CODE_PATTERN.match(detail)
    if match:
        return match.group(1), match.group(2)
    return None, detail


def _cmd_task_submit(client: RelayClient, args) -> int:
    cap, payload = _parse_stage_arg(args.stage)
    try:
        cap, payload = apply_forward_slot(cap, payload, args.forward_slot)
    except ForwardSlotError as exc:
        raise SystemExit(
            f"invalid --forward-slot {args.forward_slot!r}: {exc.message}"
            " — allowed: 1..64 chars of A-Za-z0-9_- (no whitespace, no dots)"
        )
    if cap == FORWARD_CAPABILITY and "forward_slot" not in payload:
        raise SystemExit(
            "refusing to submit capability 'forward' without a slot — pass "
            "--forward-slot <slot> or add a forward_slot key to the stage payload"
        )
    try:
        resp = client.submit_simple_task(
            cap,
            payload,
            name=args.name or "",
            priority=args.priority,
            owner_node_id=args.owner,
        )
    except httpx.HTTPStatusError as exc:
        code, _message = _parse_relay_error(exc.response)
        print(f"submit failed: HTTP {exc.response.status_code}: {exc.response.text.strip()}",
              file=sys.stderr)
        hint = forward_hint(code)
        if hint:
            print(f"hint: {hint}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(resp, default=str))
        return 0
    print(json.dumps(resp, indent=2, default=str))
    return 0


def _cmd_task_result(client: RelayClient, args) -> int:
    data = client.get_task(args.task_id)
    if "error" in data:
        print(f"Task {args.task_id}: {data['error']}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(data, default=str))
        return 0
    _print_task_result(data)
    return 0


def _cmd_task_list(client: RelayClient, args) -> int:
    """Query tasks: ``GET /relay/v2/scheduler/tasks`` (T-248).

    Every set option maps 1:1 onto a query param (server-side filtering,
    T-268); unset options are not sent. ``--status`` passes its comma
    string through unvalidated. Human rows are sorted newest-first
    (created_at desc, client-side); ``--json`` prints the full payload.
    """
    try:
        data = client.list_tasks(
            submitted_by=args.submitted_by,
            owner_node_id=args.owner,
            status=args.status,
            created_since=args.since,
            created_until=args.until,
        )
    except httpx.HTTPStatusError as exc:
        code, message = _parse_relay_error(exc.response)
        detail = f"{code}: {message}" if code else message
        print(
            f"task list failed: HTTP {exc.response.status_code}: {detail}",
            file=sys.stderr,
        )
        return 1
    if args.json:
        print(json.dumps(data, default=str))
        return 0
    tasks = sorted(
        data.get("tasks", []),
        key=lambda t: str(t.get("created_at") or ""),
        reverse=True,
    )
    if not tasks:
        print("(no tasks matched the given filters)")
        return 0
    for t in tasks:
        name = t.get("task_name") or t.get("name") or ""
        owner = t.get("owner_node_id")
        owner_str = str(owner) if owner else "-"
        print(
            f"{t.get('task_id', '?')}  {name}  {t.get('status', '?')}"
            f"  {t.get('created_at', '?')}  {t.get('submitted_by', '?')} -> {owner_str}"
        )
    return 0


def _cmd_task_note(client: RelayClient, args) -> int:
    """node-cli task note <task_id> <message> — append a note to a task.

    T-179 Task 4: ``task_id`` falls back to ``RELAY_TASK_ID`` (set by
    handler_runner for every handler) — handler scripts can post notes
    without repeating their task ID. Explicit argument wins over env.
    Without any ID → stderr message + exit 1.
    """
    task_id = args.task_id or os.environ.get("RELAY_TASK_ID")
    if not task_id:
        print(
            "note: no task_id and no RELAY_TASK_ID in env",
            file=sys.stderr,
        )
        return 1
    try:
        data = client.add_task_note(task_id, args.message)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            print(f"Task {task_id} not found", file=sys.stderr)
            return 1
        print(f"Error: {exc.response.status_code} {exc.response.text}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(data, default=str))
        return 0
    print(f"✅ Note added to task {data.get('task_id', task_id)}")
    print(f"   {data.get('message', '')} ({data.get('created_at', '')})")
    return 0


def _cmd_task_wait(client: RelayClient, args) -> int:
    task_id = args.task_id
    interval = max(1, args.interval)

    last_note_count = 0
    while True:
        data = client.get_task(task_id)
        if "error" in data:
            print(f"Task {task_id}: {data['error']}", file=sys.stderr)
            return 1

        task = data.get("task", {})
        status = task.get("status", "unknown")

        # T-052: surface any new notes that arrived since the last poll.
        notes = data.get("notes", [])
        if len(notes) > last_note_count:
            for n in notes[last_note_count:]:
                print(f"\n💬 [{n.get('node_id', '?')}] {n.get('message', '')} ({n.get('created_at', '?')})")
            last_note_count = len(notes)

        if status in ("completed", "failed", "timed_out"):
            if args.json:
                print(json.dumps(data, default=str))
                return 0 if status == "completed" else 1
            print(f"\n✅ Task {task_id} — {status}\n")
            _print_task_result(data)
            return 0 if status == "completed" else 1

        # Show spinner / progress
        stages = data.get("stages", [])
        done = sum(1 for s in stages if s.get("status") == "completed")
        total = len(stages)
        print(f"\r⏳ {status} — {done}/{total} stages completed...", end="", flush=True)
        time.sleep(interval)


def _print_task_result(data: dict[str, Any]) -> None:
    task = data.get("task", {})
    stages = data.get("stages", [])
    artifacts = data.get("artifacts", [])
    notes = data.get("notes", [])

    print(f"  Task:    {task.get('task_name', '?')} ({task.get('task_id', '?')})")
    print(f"  Status:  {task.get('status', '?')}")
    print(f"  Created: {task.get('created_at', '?')}")
    print(f"  Updated: {task.get('updated_at', '?')}")
    print()

    if stages:
        print("  Stages:")
        for s in stages:
            status_icon = "✅" if s.get("status") == "completed" else "⏳" if s.get("status") == "claimed" else "⬜"
            result_str = ""
            if s.get("result"):
                result_str = f"  result={json.dumps(s['result'])}"
            print(f"    {status_icon} {s.get('stage_name','?')} [{s.get('capability','?')}] — {s.get('status','?')}{result_str}")
            # T-053: show resolved capability metadata when present.
            cd = s.get("capability_details")
            if cd:
                if cd.get("description"):
                    print(f"       description: {cd['description']}")
                if cd.get("type"):
                    print(f"       type:        {cd['type']}")
                if cd.get("input_schema"):
                    print(f"       input_schema: {json.dumps(cd['input_schema'])}")
            # Surface handler diagnostics (exit code, stdout size,
            # stderr snippet) so callers can debug empty responses
            # without downloading artifacts. Populated by
            # handler_runner.run_handler() on success (exit 0).
            handler_info = (s.get("result") or {}).get("_handler")
            if handler_info:
                stderr_snippet = (handler_info.get("stderr") or "")[:200]
                print(
                    f"      [handler] exit={handler_info.get('exit_code')} "
                    f"stdout={handler_info.get('stdout_length','?')}B "
                    f"stderr={stderr_snippet!r}"
                )
        print()

    if artifacts:
        print("  Artifacts:")
        for a in artifacts:
            size = a.get("size_bytes", 0)
            size_str = f"{size/1024:.0f} KB" if size < 1024*1024 else f"{size/1024/1024:.1f} MB"
            print(f"    📄 {a.get('name','?')} ({a.get('artifact_id','?')}) — {size_str}")
    else:
        print("  (no artifacts linked to this task)")

    if notes:
        print()
        print(f"  Notes ({len(notes)}):")
        for n in notes:
            print(f"    💬 [{n.get('node_id', '?')}] {n.get('message', '')} ({n.get('created_at', '?')})")