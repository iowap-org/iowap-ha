#!/usr/bin/env python3
"""Shared utility functions for node-cli and related tools.

Extracted from the legacy poller.py to remove the dependency on the
old Poller class. These are thin wrappers around file I/O and config
loading used by node_cli.py and its RelayClient.
"""

import json
import logging
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path

logger = logging.getLogger("node-utils")


def _utcnow_str() -> str:
    """Current UTC time as an ISO-8601 string (token cadence anchor)."""
    return datetime.now(UTC).isoformat()


BASE_DIR = Path.home() / ".relay"
LEGACY_META_PATH = BASE_DIR / "ai-relay-agent.json"
LEGACY_TOKEN_PATH = BASE_DIR / "ai-relay-agent.token"
META_PATH = BASE_DIR / "iowap-agent.json"
CONFIG_PATH = BASE_DIR / "relay_config.json"
TOKEN_PATH = BASE_DIR / "iowap-agent.token"
STATUS_PATH = BASE_DIR / "worker_status.json"

DEFAULT_CONFIG = {
    "base_url": None,
    "heartbeat_interval": 8,
    "claim_interval": 5,
    "status_interval": 7200,
    # T-182: fixed maintenance intervals instead of expiry-margin math.
    # rt (TTL 7d): refresh every 6 days. rs (TTL 7d): rotate on every
    # start + every 24h. Env overrides: RELAY_RS_REFRESH_INTERVAL /
    # RELAY_RT_REFRESH_INTERVAL (seconds).
    "rs_refresh_interval_seconds": 86400,
    "rt_refresh_interval_seconds": 518400,
    "request_timeout": 10,
    "task_timeout": 600,
    "log_level": "INFO",
    "background_heartbeat": True,
    # T-060: how many times the daemon retries a task before refusing
    # to claim more stages for it (3 attempts total with the default of 2).
    "max_retries": 2,
}


def load_json(path: Path, default=None):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text())
    except Exception as exc:
        logger.warning("failed to read %s: %s", path, exc)
        return default


def write_json_atomic(path: Path, data: dict):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, default=str))
    os.chmod(tmp, 0o600)
    tmp.replace(path)
    os.chmod(path, 0o600)


def load_config() -> dict:
    cfg = load_json(CONFIG_PATH, default=DEFAULT_CONFIG.copy())
    if cfg is None:
        cfg = DEFAULT_CONFIG.copy()
    for key, value in DEFAULT_CONFIG.items():
        cfg.setdefault(key, value)
    return cfg


def load_meta() -> dict:
    path = META_PATH if META_PATH.exists() else LEGACY_META_PATH
    if not path.exists():
        raise FileNotFoundError(f"metadata missing: {META_PATH} (legacy: {LEGACY_META_PATH})")
    return json.loads(path.read_text())


def load_token() -> dict | None:
    """Load the persisted runtime token as a dict.

    Returns ``{"token": "...", "expires_at": "..." | None}`` or ``None``
    when no token file exists. Legacy plaintext token files (pre-T-088)
    are detected — a single non-JSON line is treated as the token value
    with an unknown expiry — and migrated to the JSON format on the next
    ``save_token()`` call.
    """
    if not TOKEN_PATH.exists() and not LEGACY_TOKEN_PATH.exists():
        return None
    token_path = TOKEN_PATH if TOKEN_PATH.exists() else LEGACY_TOKEN_PATH
    raw = token_path.read_text().strip()
    if not raw:
        return None
    # T-088: prefer the JSON envelope. Fall back to the legacy
    # plaintext format so existing installs keep working.
    if raw.lstrip().startswith("{"):
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("token file %s is not valid JSON, treating as plaintext", TOKEN_PATH)
            return {"token": raw, "expires_at": None, "refreshed_at": None}
        if isinstance(data, dict) and data.get("token"):
            return {
                "token": data["token"],
                "expires_at": data.get("expires_at"),
                # T-185: cadence anchor for the 6-day rt interval; None
                # means "unknown" (legacy envelope) — the daemon then
                # stamps it on the next rotation.
                "refreshed_at": data.get("refreshed_at"),
            }
        return None
    return {"token": raw, "expires_at": None, "refreshed_at": None}


def save_token(
    token: str, expires_at: str | None = None, refreshed_at: str | None = None
) -> None:
    """Persist the runtime token plus its expiry as a JSON envelope.

    The envelope is
    ``{"token": "...", "expires_at": "...|None", "refreshed_at": "...|None"}``.
    ``refreshed_at`` (T-185) is the cadence anchor for the 6-day rt
    refresh interval: it counts from the LAST REFRESH, not from daemon
    start, so the stamp must survive restarts on disk. ``None`` stamps
    the current UTC time — every token write IS a refresh of the
    credential. Writing is atomic (tmp file + rename) so a crash
    mid-write never leaves a truncated token file. The file is chmod
    0o600 so other local users cannot read the token (security
    hardening, T-171).
    """
    if refreshed_at is None:
        refreshed_at = _utcnow_str()
    tmp = TOKEN_PATH.with_suffix(TOKEN_PATH.suffix + ".tmp")
    tmp.write_text(
        json.dumps(
            {"token": token, "expires_at": expires_at, "refreshed_at": refreshed_at}
        )
        + "\n"
    )
    os.chmod(tmp, 0o600)
    tmp.replace(TOKEN_PATH)
    os.chmod(TOKEN_PATH, 0o600)
    # Migrate: remove legacy token file after successful write
    if LEGACY_TOKEN_PATH.exists() and LEGACY_TOKEN_PATH != TOKEN_PATH:
        LEGACY_TOKEN_PATH.unlink(missing_ok=True)


def save_meta(meta: dict):
    write_json_atomic(META_PATH, meta)
    # Migrate: remove legacy file after successful write
    if LEGACY_META_PATH.exists() and LEGACY_META_PATH != META_PATH:
        LEGACY_META_PATH.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# PID helpers (T-117): parameterised so node_cli, node_daemon and a future
# federation_node can share them. Each caller passes its own pid_path.
# ---------------------------------------------------------------------------

def read_pid(pid_path: Path) -> int | None:
    """Read a PID file and return the pid, or ``None`` if missing/invalid."""
    if not pid_path.exists():
        return None
    try:
        return int(pid_path.read_text().strip())
    except (ValueError, OSError):
        return None


def pid_running(pid: int) -> bool:
    """Return True if a process with the given pid is currently alive."""
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


# ---------------------------------------------------------------------------
# T-062: git repo update helpers (update check / update apply)
# ---------------------------------------------------------------------------

# Location of the deployed repository on a node. Overridable via env var
# RELAY_REPO_DIR so tests (or non-standard installs) can point it elsewhere.
REPO_DIR = Path(os.environ.get("RELAY_REPO_DIR", str(Path.home() / "projects" / "iowap-server")))

# systemd user unit name restarted by `update apply`. Overridable via env
# RELAY_SERVICE_UNIT so tests can substitute a no-op service name.
SERVICE_UNIT = os.environ.get("RELAY_SERVICE_UNIT", "iowap-node-daemon.service")


def _git(args: list[str], *, cwd: Path, timeout: float = 30.0) -> subprocess.CompletedProcess:
    """Run a git command inside ``cwd`` and return the completed process.

    Raises CalledProcessError on non-zero exit so callers can distinguish a
    real failure from empty-but-valid output (e.g. ``git rev-list --count``
    before any upstream exists).
    """
    return subprocess.run(
        ["git", *args],
        cwd=str(cwd),
        capture_output=True,
        text=True,
        timeout=timeout,
        check=True,
    )


def get_repo_info(repo_dir: Path | None = None) -> dict:
    """Return a snapshot of the local repo vs. its configured upstream.

    The dict contains:
      - ``local_commit``:    SHA of HEAD (or None if not a git repo)
      - ``local_branch``:    current branch name (or "" for detached HEAD)
      - ``remote_commit``:   SHA of the upstream tracking branch (or None)
      - ``behind_count``:    number of commits local is behind upstream
                             (0 when no upstream is configured)
      - ``has_upstream``:    bool whether an upstream is configured
    """
    repo = repo_dir or REPO_DIR
    info: dict = {
        "local_commit": None,
        "local_branch": "",
        "remote_commit": None,
        "behind_count": 0,
        "has_upstream": False,
    }
    if not (repo / ".git").exists() and not repo.exists():
        return info
    try:
        info["local_commit"] = _git(["rev-parse", "HEAD"], cwd=repo).stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        return info
    try:
        info["local_branch"] = _git(["rev-parse", "--abbrev-ref", "HEAD"], cwd=repo).stdout.strip()
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        info["local_branch"] = ""
    try:
        info["remote_commit"] = _git(["rev-parse", "@{upstream}"], cwd=repo).stdout.strip()
        info["has_upstream"] = bool(info["remote_commit"])
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        info["remote_commit"] = None
        info["has_upstream"] = False
    if info["has_upstream"]:
        try:
            count = _git(["rev-list", "--count", "HEAD..@{upstream}"], cwd=repo).stdout.strip()
            info["behind_count"] = int(count) if count.isdigit() else 0
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, ValueError):
            info["behind_count"] = 0
    return info


def check_for_updates(repo_dir: Path | None = None) -> dict:
    """Run ``git fetch origin`` and return ``get_repo_info()`` afterwards.

    The fetch is best-effort: network failures are logged and the current
    repo info is still returned so callers can display the last-known state.
    """
    repo = repo_dir or REPO_DIR
    try:
        _git(["fetch", "origin"], cwd=repo, timeout=60.0)
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired) as exc:
        logger.warning("git fetch failed: %s", exc)
    return get_repo_info(repo_dir=repo)


def apply_update(repo_dir: Path | None = None, *, service_unit: str | None = None) -> dict:
    """Pull the latest commits and restart the node-cli systemd service.

    Returns a dict with:
      - ``success``:        bool
      - ``message``:        human-readable summary
      - ``before_commit``:  SHA before the pull (or None)
      - ``after_commit``:   SHA after the pull (or None)
      - ``behind_before``:  behind_count before the pull
      - ``behind_after``:   behind_count after the pull
      - ``restarted``:      bool whether the service restart was attempted
    """
    repo = repo_dir or REPO_DIR
    unit = service_unit or SERVICE_UNIT
    before = get_repo_info(repo_dir=repo)
    result: dict = {
        "success": False,
        "message": "",
        "before_commit": before.get("local_commit"),
        "after_commit": None,
        "behind_before": before.get("behind_count", 0),
        "behind_after": 0,
        "restarted": False,
    }
    try:
        _git(["pull"], cwd=repo, timeout=120.0)
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired) as exc:
        result["message"] = f"git pull failed: {exc}"
        return result
    after = get_repo_info(repo_dir=repo)
    result["after_commit"] = after.get("local_commit")
    result["behind_after"] = after.get("behind_count", 0)
    # Restart the systemd user service so the new code is loaded.
    try:
        subprocess.run(
            ["systemctl", "--user", "restart", unit],
            capture_output=True,
            text=True,
            timeout=60.0,
            check=True,
        )
        result["restarted"] = True
        result["success"] = True
        if result["before_commit"] == result["after_commit"]:
            result["message"] = f"already up to date ({result['after_commit']}); service restarted"
        else:
            result["message"] = (
                f"updated {result['before_commit']} -> {result['after_commit']}; "
                f"service restarted"
            )
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired) as exc:
        result["message"] = (
            f"pull ok ({result['before_commit']} -> {result['after_commit']}) but "
            f"service restart failed: {exc}"
        )
        result["success"] = False
    return result
